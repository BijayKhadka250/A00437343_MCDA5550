package ibm.com.layouts.ui.funActivity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import ibm.com.layouts.R;


public class FunRecyclerViewVerticalListAdapter extends RecyclerView.Adapter<FunRecyclerViewVerticalListAdapter.FoodViewHolder> {
    private List<FoodsModel> foodsList;
    Context context;

    public FunRecyclerViewVerticalListAdapter(List<FoodsModel> foodsModelList, Context context) {
        this.foodsList = foodsModelList;
        this.context = context;
    }


    @Override
    public FoodViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View foodLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.fun_confimation_screen_foods_layout, parent, false);
        FoodViewHolder foodViewHolder = new FoodViewHolder(foodLayoutView);
        return foodViewHolder;

    }

    @Override
    public void onBindViewHolder(FoodViewHolder holder, final int position) {
        holder.foodImageView.setImageResource(foodsList.get(position).getFoodImage());
        holder.foodTextView.setText(foodsList.get(position).getFoodName());
        holder.foodsLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String foodName = foodsList.get(position).getFoodName();
                Toast.makeText(context, foodName + " is selected", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return foodsList.size();
    }

    public class FoodViewHolder extends RecyclerView.ViewHolder{
        ImageView foodImageView;
        TextView foodTextView;
        ConstraintLayout foodsLayout;

        public FoodViewHolder(View view) {
            super(view);
            foodImageView =view.findViewById(R.id.food_image_view);
            foodTextView = view.findViewById(R.id.food_name_text_view);
            foodsLayout = view.findViewById(R.id.foods_layout);
        }
    }

}
