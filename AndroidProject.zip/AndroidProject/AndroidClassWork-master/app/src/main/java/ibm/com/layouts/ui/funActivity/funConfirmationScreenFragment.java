package ibm.com.layouts.ui.funActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import ibm.com.layouts.R;



public class funConfirmationScreenFragment extends Fragment {

    private List<FoodsModel> foodsList = new ArrayList<>();
    private RecyclerView foodsRecyclerView;
    private FunRecyclerViewVerticalListAdapter foodsAdapter;
    String firstName;
    String lastName;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fun_confirmation_screen, container, false);
        firstName = funConfirmationScreenFragmentArgs.fromBundle(getArguments()).getFirstName();
        lastName = funConfirmationScreenFragmentArgs.fromBundle(getArguments()).getLastName();

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        populateHeader(view);
        populateRecycleView(view);

    }
    private void populateHeader(View view){
        TextView headerTextView = view.findViewById(R.id.fun_header_text_view);
        headerTextView.setText("Hello " + firstName+ " " +lastName);
    }

    private void populateRecycleView(View view){
        foodsRecyclerView = view.findViewById(R.id.foods_recycler_view);
        foodsRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(),LinearLayoutManager.VERTICAL));

        foodsAdapter = new FunRecyclerViewVerticalListAdapter(foodsList,getActivity()) ;
        LinearLayoutManager verticalLayoutManager = new LinearLayoutManager(getActivity(),LinearLayoutManager.VERTICAL,false);

        foodsRecyclerView.setLayoutManager(verticalLayoutManager);
        foodsRecyclerView.setAdapter(foodsAdapter);


        populateFoodsList();
    }

    private void populateFoodsList(){
        FoodsModel food1 = new FoodsModel(R.drawable.food,"burgar");
        FoodsModel food2 = new FoodsModel(R.drawable.food,"mo:mo");
        FoodsModel food3 = new FoodsModel(R.drawable.food,"chaumin");
        FoodsModel food4 = new FoodsModel(R.drawable.food,"rice");
        FoodsModel food5 = new FoodsModel(R.drawable.food,"curry");
        FoodsModel food6 = new FoodsModel(R.drawable.food,"fried egg");
        FoodsModel food7 = new FoodsModel(R.drawable.food,"samosa");
        FoodsModel food8 = new FoodsModel(R.drawable.food,"salad");
        FoodsModel food9 = new FoodsModel(R.drawable.food,"jerry");
        FoodsModel food10 = new FoodsModel(R.drawable.food,"roti");


        foodsList.add(food1);
        foodsList.add(food2);
        foodsList.add(food3);
        foodsList.add(food4);
        foodsList.add(food5);
        foodsList.add(food6);
        foodsList.add(food7);
        foodsList.add(food8);
        foodsList.add(food9);
        foodsList.add(food10);


        foodsAdapter.notifyDataSetChanged();


    }

}
