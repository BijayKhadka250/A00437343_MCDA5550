# AndroidClassWork
Full Android Project covered in class (Includes layouts, login screen, navigation and recycler view)
